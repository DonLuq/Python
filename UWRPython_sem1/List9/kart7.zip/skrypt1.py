
def licz():
    Lista = []
    for i in range(10):
        print(i+1)
        Lista.append(i+1)
    return Lista
licz()